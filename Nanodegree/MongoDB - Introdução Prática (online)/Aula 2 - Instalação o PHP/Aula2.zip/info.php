﻿<?php

phpinfo();

?>
