/*

	NomeFun��o([Argumentos])

	CAST(Valor Refer�ncia AS Tipo de Dado)

	CONVERT(Tipo de Dado,Valor Refer�ncia,Estilo)

	Onde Estilo ser� aplicado para datas e possui c�digos de 1 a 14 (Ano Sem S�culo)

	e 101 1 114 (Ano Com S�culo)

	FORMAT(Valor Refer�ncia,Formato,Cultura/Pa�s)

	EX:

	Format(Campo Monet�rio,'C','en-us')
	Format(Campo Monet�rio,'C','pt-br')

	Format(Campo Data,'d','pt-br')
	Format(Campo Data,'D','pt-br')
	Format(Campo Data,'dd - mm - yyyy','pt-br')

*/

