/*

	NomeFun��o([Argumentos])

	LEN(Texto Pesquisado)

	LEFT(Texto Pesquisado,N� de caracteres)

	RIGHT(Texto Pesquisado,N� de caracteres)

	REPLACE(Texto Pesquisado,Texto Localizado,Texto Substitui��o)

	CHARINDEX(Texto Pesquisado,Texto Localizado,Posi��o Inicial)

	SUBSTRING(Texto Pesquisado,Posi��o Inicial,N� de Caracteres)

	RTRIM(Texto Pesquisado)

	LTRIM(Texto Pesquisado)

	UPPER(Texto Pesquisado)

	LOWER(Texto Pesquisado)

	REPLICATE(Texto a Repetir,Quantidade de Vezes)

	REVERSE(Texto a ser Invertido)
	
	STRING_SPLIT(Texto a ser separado,Caractere delimitador)

*/

