-- Retornar o comprimento de um texto
-- LEN(texto)

-- Retornar os primeiros caracteres da esquerda
-- LEFT(texto,n� de caracteres)

-- Retornar os �ltimos caracteres da direita
-- RIGHT(texto,n� de caracteres)

-- Substituir um texto por outro
-- REPLACE(texto,'valor anterior','novo valor')

