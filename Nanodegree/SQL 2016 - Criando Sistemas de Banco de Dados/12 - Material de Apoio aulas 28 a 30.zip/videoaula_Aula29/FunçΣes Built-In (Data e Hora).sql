/*

	NomeFun��o([Argumentos])

	GETDATE()

	DAY(Data Refer�ncia)

	MONTH(Data Refer�ncia)

	YEAR(Data Refer�ncia)

	EMONTH(Data Refer�ncia,Quantidade de meses a adicionar)

	DATEFROMPARTS(Ano,M�s,Dia)

	DATEDIFF(Parte Data,Data Inicial,Data Final)

	DATEADD(Parte Data,valor a ser adicionado,Data Refer�ncia)

	DATENAME(Data Refer�ncia,Parte Data)

	onde Parte Data poder� ser:

		> YEAR		YYYY
		> QUARTER	Q
		> MONTH		M
		> WEEK		WW
		> DAY		D

*/

