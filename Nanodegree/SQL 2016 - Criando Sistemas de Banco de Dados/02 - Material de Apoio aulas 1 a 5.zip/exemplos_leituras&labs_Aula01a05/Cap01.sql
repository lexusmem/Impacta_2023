--COMANDO DE CONSULTA SQL
SELECT * FROM TB_DEPARTAMENTO

-- Coment�rio
-- Primeira aula de SQL Server

-- O comando a seguir executa uma consulta que retorna as informa��es da tabela de departamentos
SELECT ...


/*
Bloco de texto comentado que n�o � executado pelo SQL
*/
